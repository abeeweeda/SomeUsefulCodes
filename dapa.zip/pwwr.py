import pandas as pd
import numpy as np
import matplotlib as mpl
mpl.use('nbAgg')#just for jupyter notebook
import matplotlib.pyplot as plt
import seaborn as sns
import statsmodels as sm

#creating features
Train_Data = pd.read_excel(r'dada.xlsx')#put your own path
Train_Data.rename(columns={"Date":"Date_Time"}, inplace=True)
Train_Data['Date'] = Train_Data['Date_Time'].dt.date
Train_Data['Month'] = Train_Data['Date_Time'].dt.month
Train_Data['DayofWeek'] = Train_Data['Date_Time'].dt.dayofweek
Train_Data['Hour'] = Train_Data['Date_Time'].dt.hour
Train_Data['Year'] = Train_Data['Date_Time'].dt.year
Train_Data['Day'] = Train_Data['Date_Time'].dt.day
Train_Data['Time'] = Train_Data['Date_Time'].dt.time
#dayofweek = {0:'Mon',1:'Tue',2:'Wed',3:'Thu',4:'Fri',5:'Sat',6:'Sun'}

Train_Data.drop('National Public Holidays', axis=1, inplace=True)

from sklearn.ensemble import RandomForestRegressor
from sklearn.ensemble import ExtraTreesRegressor

y = Train_Data['Original Load']
X = Train_Data.drop(['Original Load', 'Date', 'Date_Time', 'Time'], axis=1)

### this one is the model which is giving best result without doing any thing
extr = ExtraTreesRegressor(n_estimators=400, max_depth=20,min_samples_split=2, random_state=0)
X_train, X_test, y_train, y_test = X[:-720], X[-720:], y[:-720], y[-720:]
model = extr
model.fit(X_train, y_train)
from sklearn.metrics import mean_squared_error
np.sqrt(mean_squared_error(model.predict(X_test),y_test))
np.mean(np.abs((y_test - model.predict(X_test)) / y_test)) * 100
########## ...............

##below code is splitted into daily then hourly and we do like 24*7 predictions, not very good result
#creating features
Train_Data = pd.read_excel(r'dada.xlsx')#put your own path
Train_Data.rename(columns={"Date":"Date_Time"}, inplace=True)
Train_Data['Date'] = Train_Data['Date_Time'].dt.date
Train_Data['Month'] = Train_Data['Date_Time'].dt.month
Train_Data['DayofWeek'] = Train_Data['Date_Time'].dt.dayofweek
Train_Data['Hour'] = Train_Data['Date_Time'].dt.hour
Train_Data['Year'] = Train_Data['Date_Time'].dt.year
Train_Data['Day'] = Train_Data['Date_Time'].dt.day
Train_Data['Time'] = Train_Data['Date_Time'].dt.time
#dayofweek = {0:'Mon',1:'Tue',2:'Wed',3:'Thu',4:'Fri',5:'Sat',6:'Sun'}

import statsmodels.api as sm
from sklearn.ensemble import RandomForestRegressor
RF = RandomForestRegressor(n_estimators=10)
Train_Data_New = Train_Data.copy()
all_mape = []
preds = []
test_ys = []
for dy in dys:
    for hr in hrs:
        Train_Data_hr = Train_Data_New[(Train_Data.Hour==hr)&(Train_Data.Day==dy)].copy()
        Train_Data_hr_X = Train_Data_hr[['Temperature', 'Humidity',
           'National Public Holidays', 'State Public Holidays',
           'Month', 'Day', 'Year', 'DayofWeek','National Public Holidays']][:-4]
        Train_Data_hr_Y = Train_Data_hr['Original Load'][:-4]
        Test_Data_hr_X = Train_Data_hr[['Temperature', 'Humidity',
           'National Public Holidays', 'State Public Holidays',
           'Month', 'Day', 'Year', 'DayofWeek','National Public Holidays']][-4:]
        Test_Data_hr_Y = Train_Data_hr['Original Load'][-4:]
        model = forest.fit(Train_Data_hr_X, Train_Data_hr_Y)
        predicts = model.predict(Test_Data_hr_X)
#         model = sm.OLS(Train_Data_hr_Y,Train_Data_hr_X)
#         results = model.fit()
#         predicts = results.predict(Test_Data_hr_X)
        preds.append(predicts)
        test_ys.append(Test_Data_hr_Y)
        all_mape.append(np.mean(np.abs((Test_Data_hr_Y - predicts) / Test_Data_hr_Y)) * 100)
        #print(np.mean(np.abs((Test_Data_hr_Y - predicts) / Test_Data_hr_Y)) * 100)
test_ys = np.array(test_ys)
preds = np.array(preds)
np.mean(np.abs((test_ys - preds) / test_ys)) * 100, sum(all_mape)/168

########################################

##below code only splits data into hourly , results in par with the first extratreeregssor code
#creating features
Train_Data = pd.read_excel(r'dada.xlsx')#put your own path
Train_Data.rename(columns={"Date":"Date_Time"}, inplace=True)
Train_Data['Date'] = Train_Data['Date_Time'].dt.date
Train_Data['Month'] = Train_Data['Date_Time'].dt.month
Train_Data['DayofWeek'] = Train_Data['Date_Time'].dt.dayofweek
Train_Data['Hour'] = Train_Data['Date_Time'].dt.hour
Train_Data['Year'] = Train_Data['Date_Time'].dt.year
Train_Data['Day'] = Train_Data['Date_Time'].dt.day
Train_Data['Time'] = Train_Data['Date_Time'].dt.time
#dayofweek = {0:'Mon',1:'Tue',2:'Wed',3:'Thu',4:'Fri',5:'Sat',6:'Sun'}

import statsmodels.api as sm
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error
RF = RandomForestRegressor(n_estimators=10)
Train_Data_New = Train_Data.copy()
all_mape = []
preds = []
test_ys = []
Forecast_df = pd.DataFrame()
Forecast_df['Original Load'] = np.NaN
Forecast_df['Date_Time'] = np.NaN
for hr in hrs:        
    Train_Data_hr = Train_Data_New[Train_Data.Hour==hr].copy()
    Train_Data_hr_X = Train_Data_hr[['Temperature', 'Humidity',
       'State Public Holidays',
       'Month', 'Year', 'DayofWeek']][:-28]
    Train_Data_hr_Y = Train_Data_hr['Original Load'][:-28]
    Test_Data_hr_X = Train_Data_hr[['Temperature', 'Humidity',
       'State Public Holidays',
       'Month', 'Year', 'DayofWeek']][-28:]
    Test_Data_hr_Y = Train_Data_hr['Original Load'][-28:]
    model = forest.fit(Train_Data_hr_X, Train_Data_hr_Y)
    predicts = model.predict(Test_Data_hr_X)
    Forecast_df_temp = pd.DataFrame({'Date_Time':Train_Data_hr['Date_Time'][-28:],'Original Load':predicts})
    Forecast_df=pd.concat([Forecast_df, Forecast_df_temp])
    preds.append(predicts)
    test_ys.append(Test_Data_hr_Y)
    all_mape.append(np.mean(np.abs((Test_Data_hr_Y - predicts) / Test_Data_hr_Y)) * 100)
    #print(np.mean(np.abs((Test_Data_hr_Y - predicts) / Test_Data_hr_Y)) * 100)
test_ys = np.array(test_ys)
preds = np.array(preds)
Forecast_df = Forecast_df.sort_index()
np.mean(np.abs((test_ys - preds) / test_ys)) * 100, sum(all_mape)/len(all_mape), len(all_mape), np.sqrt(mean_squared_error(test_ys, preds))