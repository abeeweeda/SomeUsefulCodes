
#** you can always use https://scikit-learn.org for details on any of the below topics

#basic imports
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import os#to locate and read files
#other imports we can do whenever needed

#loading all the .csv's using os
filenames = os.listdir(dataFolder)
for file in filenames:
    if file.endswith('csv'):
        #load file or do something
#also you can do something like this
filenames = [file for file in os.listdir(filepath) if file.endswith('.csv')]

#after you have read the file few things you should do
data.shape#prints the shape row vs columns
data.describe()#gives an overview of the numerical columns
data.head()#prints the first five rows so that you can get an idea of what data looks like
data.info()#this also you can do, this will give you non null count of the columns and there datatype
data.apply(lambda x : sum(x.isnull()))#this will give you number of null values of each columns

#to get the numerical columns
num_cols = Data.describe().columns#as describe only gives stats on numerical columns, similarly you can use describe(include=['O']) for string or other columns

#train test split, if your data is not having training and testing data seperate, you can do the split yourself
#before you do your train test split you need to seperate your explanatory and dependent variable (your X and y)
y = data['Survived']
X = data.drop('Survived', axis=1)#we are using titanic data set here, here survived is the dependent variable
#other way to do the above X, y seperation is
y = data.pop('Survived')#it will pop out the Survived column from original data changing the original data and assign it to y
X = data#as survived(y) column is popped out the remaining is X
y.shape, X.shape#you can print the shapes of X and y to cross check
#now you can do the train test split
from sklearn.model_selection import train_test_split
#here stratify=y means y values will be equally representative in both train and test set
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.30, random_state=42, stratify=y)

#now as we have data some preprocessing needs to be done to feed the data into the algorithm
#we treat out test data as seperate as we have not seen it, we do our preprocessing on train data and then apply those preprocessing to test data based on train data
#getting unique count of variables
X_train.nunique()#or we can use X_train.apply(lambda x : x.nunique())
#it will output all the variable and there unique count, from here we can see how many variable have less distict values and then we can check for categorical variables
#for categorical variables we can do one hot encoding using pd.get_dummies, 
#also we need to make sure that all the categories in the training data is also in test data else we will get unequal number of columns and the algo will fail

#droping unwanted cols based in unique count, if columns is an id column or a string column with most of the values as distict we can drop those
X_train.drop('PassengerId', inplace=True, axis=1)
X_test.drop('PassengerId', inplace=True, axis=1)
X_train.drop('Ticket', inplace=True, axis=1)
X_test.drop('Ticket', inplace=True, axis=1)

#imputing null values
#first thing you should always impute the null values as many other preprocessing algos might not work on null data
#in out data we have two columns with some missing data, one is Age, other is Cabin
#from printing the null count we noticed that Cabin has most of the values as null, so we can simply drop this column both from test and train
X_train.drop('Cabin', inplace=True, axis=1)
X_test.drop('Cabin', inplace=True, axis=1)
#now we have to impute the null values of column Age
#there are few ways to impute values
#you can use fillna and fill it will mean to median value
value_to_fill = X_train['Age'].median()
#or
value_to_fill = X_train['Age'].mean()
#and then use
X_train.fillna(value_to_fill)#similar you can do for test data, generally we use the train data values to impute the test data also
#or you can use the imputer from skearn.preprocessing
from sklearn.preprocessing import Imputer
imputer = Imputer(strategy='mean')#here we are filling with mean values
imputer.fit()
imputer.fit(X_train['Age'].values.reshape(-1,1))#here we have to reshape as we are only fitting a single colums and it expects a 2d data structure
#to check the value which will be imputed we can do
imputer.statistics_#returns the mean value as we chose strategy='mean' this values will be same as X_train['Age'].mean()
#now we can use the fitted value to impute the values using transform
X_train['Age'] = imputer.transform(X_train['Age'].values.reshape(-1,1))
#here we fitted and transformed seperately as we can use the imputer which we get after fitting to transform the test data also 
#** the above mentioned is generally the way we do for most other preprocessing
#if we dont want to do that we have a single fucntion fit_transform which we can use to do it in single line
X_test['Age'] = imputer.transform(X_test['Age'].values.reshape(-1,1))#here we are using the same imputer to transform the test data also
#other ways to impute data is to treat the missing data column as dependent variable and fit a model on the non null values of that column
#and then use that model to predict the null values of that column, we generally use KNN (nearest neighbour) for this
#also you can use some other imputation packages which will do this for you
#also you can define your own way which makes more sense to you to fill the null values one such logic we will use here
#the logic for imputing data which we are going to use here is
#as from names column we can see names have Mr. Mrs. Miss Master, we can extract that data from name column and then find the median in each group and then use this for imputation
#we creater one more columns based on Master Header for both train and test
X_train['Name_Header'] = X_train['Name'].str.extract(r'(Mr\.|Miss\.|Mrs\.|Master\.)')
X_test['Name_Header'] = X_test['Name'].str.extract(r'(Mr\.|Miss\.|Mrs\.|Master\.)')
#we see now that we have some null values in our Name_Header, as those names do not have any of Mr/Mrs/Master/Miss
#to fill those nulls we can simple put Mr. for Males and Mrs. for Females
X_train['Name_Header'].fillna(X_train.loc[X_train['Name_Header'].isnull(),'Sex'], inplace=True) 
X_test['Name_Header'].fillna(X_test.loc[X_test['Name_Header'].isnull(),'Sex'], inplace=True)#we are filling the values from Sex columns to NaN's in Name_Header
mapping = {'male':'Mr.', 'female':'Mrs.','Mr.':'Mr.','Miss.':'Miss.','Master.':'Master.','Mrs.':'Mrs.'}
#creat a dictionary which will be used to map male to Mr and female to Mrs, also we need all the other values in the mapping otherwise those values will be filled as null
X_train['Name_Header'] = X_train['Name_Header'].map(mapping)#using the above mapping as we want Mr and Mrs not male and female in Name_Header column
X_test['Name_Header'] = X_test['Name_Header'].map(mapping)
#the above is one way to do it may be not very efficient but you can see the working of map
#now drop the original Name columns
X_train.drop('Name', inplace=True, axis=1)
X_test.drop('Name', inplace=True, axis=1)
#now we will impute the null values for column Age based on median value in each group for Name_Header
X_train['Age'] = X_train.groupby('Name_Header')['Age'].transform(lambda x: x.fillna(x.median()))
X_test['Age'] = X_test.groupby('Name_Header')['Age'].transform(lambda x: x.fillna(x.median()))#you can also use the grouped values from train data, depending on the scenario
X_train['Embarked'].fillna(X_train['Embarked'].mode()[0], inplace=True)#filling few null in Embarked using mode, as we can not use median ot mean for string values
#X_train['Embarked'].mode()[0] returns the mode value, if you write only X_train['Embarked'].mode() it returns a series and the fillna function wont work with it
['Fare'] = X_test.groupby('Name_Header')['Fare'].transform(lambda x: x.fillna(x.mean()))#filling the null value in Fare column in test data
#now all the null values are filled and we have zero nulls in each column

#one hot encoding, or creating dummy variables, and Label Encoding
#most machine learning algo dont work very well with categorical variables so we can create dummy variable
#e.g. if we have 3 distinct values, we ca represnt them as 00, 10, 01 using two variable or we can use three variable for each values and the one having 1 is the value for that row
#when we create dummy variable for a column we create as many columns as the number of distinct values in our columns
#some minute difference between one hot encoding and get_dummies
#OneHotEncoder cannot process string values directly. If your nominal features are strings, then you need to first map them into integers
#pandas.get_dummies is kind of the opposite. By default, it only converts string columns into one-hot representation, unless columns are specified
#sometimes some algorithms can handle cateorical variable just fine, in that case you don't need to do the one hot encoding, all you can do is use LabelEncoder
#**also when our varible is ordinal like small<medium<big we use LabelEncoder but when we have something like cat dog rat we can't say cat>dog>rat so we use one hot encoding
#also we can use LabelEncoder if we have a binary variable like Male/Female
from sklearn.preprocessing import LabelEncoder
LE = LabelEncoder()#defining a label encoder
LE.fit(X_train['Sex'])#fitting only on the train data as we want the same encoding for test as we have for train
X_train['Sex'] = LE.transform(X_train['Sex'])#encoding train data as per train data fit
X_test['Sex'] = LE.transform(X_test['Sex'])#encoding train data as per train data fit just be sure that if we are using 1 for male in train same should be for test
#now creating dummy variables, also must remember that all the values of a variable should be present in both train and test data else we will have unequal number of columns
#one solution is that we can concat the two data and then create dummy variables or we can use one hot encoder from sklearn
#for us we have all the values on both train and test so we can simply use pd.get_dummies on both train and test
columns_to_dummy = ['Pclass','Embarked','Name_Header']
for col in columns_to_dummy:
    X_train = pd.concat([X_train, pd.get_dummies(X_train[col], prefix=col)], axis=1)
    X_test = pd.concat([X_test, pd.get_dummies(X_test[col], prefix=col)], axis=1)#creating dummies and concatinating, axis=1 means add as columns
X_train.drop(columns_to_dummy, axis=1, inplace=True)
X_test.drop(columns_to_dummy, axis=1, inplace=True)#droping the original cols

#for some algorithms we might need to scale the data in order to run the algorithm more effectively, we can do that using below methods depending on the problem
from sklearn.preprocessing import StandardScaler#z = (x - mu) / sigma, mu=mean, sigma=standard deviation
from sklearn.preprocessing import MinMaxScaler#z = (x - min(x)) / (max(x) - min(x))
from sklearn.preprocessing import Normalizer#not sure

#**many of the above steps might not be necessary and may or may not affect the performance of the model
#also they can be performed in many different ways
#we followed many steps just for tutorial purpose and to give you an idea on how to approach a problem
#usually we do may hit and trials and see if the extra steps done in preprocessing are really worth it
#but some steps are necessary like doing encoding as most models require numerical data or imputing as many models can't work with null values etc
#feature engineering generally helps but creating unwanted features may also degrade the model

#now for our problem the data is prepared and now we can proceed to apply algorithms
#as our goal is to predict wheather the passenger survived or not either 1 or 0, its a classification problem and as we have labelled data its a supervised learning problem
#which mean our model will learn based on the data and labels and then apply that learning to predict the labels of test data

#a general thing for all the models will be importing the model, fitting the data and then making predictions on the test data
#below we will be fitting just some basic models without any tuning (** hyperparameter tuning tends to improve the model) and check the score
#further we will explore each model in detail coming forward

#model1 - logistic regression
from sklearn.linear_model import LogisticRegression
LogR = LogisticRegression()
LogR.fit(X_train, y_train)
predictions = LogR.predict(X_test)
predictFrame = pd.DataFrame({'PassengerId':pd.read_csv(r'..\..\..\\tita\\test.csv')['PassengerId'],'Survived':predictions})#create a dataframe of the predictions
predictFrame.to_csv(r'..\..\..\\tita\\logisticBasic.csv', index=False)#save to csv to upload to kaggle as we don't have the original output
#the output score comes to be 0.78468

#model2 - decision tree
from sklearn.tree import DecisionTreeClassifier
Detree = DecisionTreeClassifier()
Detree.fit(X_train, y_train)
predictions = Detree.predict(X_test)
#the output score comes to be 0.65071

#model3 - extra tree
from sklearn.ensemble import ExtraTreesClassifier
Extree = ExtraTreesClassifier()
Extree.fit(X_train, y_train)
predictions = Extree.predict(X_test)
#the output score comes to be 0.73205

#model4 - random forest
from sklearn.ensemble import RandomForestClassifier
RandF = RandomForestClassifier()
RandF.fit(X_train, y_train)
predictions = RandF.predict(X_test)
#the output score comes to be 0.74641

#model5 - XGB - extreme gradient boosting
from xgboost import XGBClassifier
XGB = XGBClassifier()
XGB.fit(X_train, y_train)
predictions = XGB.predict(X_test)
#the output score comes to be 0.77990

#now i have got the actual score which i got from the web now i can use those to score my algos
actualpredictions = pd.read_csv(r'..\..\..\\tita\\perfectScore.csv')['Survived'].values#actual answers for titanic data set
#one way of getting score of a simple binary problem is using numpy array
1-abs(actualpredictions-predictions).mean()#this will give me the accuracy score
#we can do the same using accuracy score
from sklearn.metrics import accuracy_score
accuracy_score(actualpredictions, predictions)#this will give us the same output as above

#model6 - Adaboost
from sklearn.ensemble import AdaBoostClassifier
Ada = AdaBoostClassifier()
Ada.fit(X_train, y_train)
predictions = Ada.predict(X_test)
#the output score comes to be 0.765550

#model7 - Gradient Boosting
from sklearn.ensemble import GradientBoostingClassifier
GBM = GradientBoostingClassifier()
GBM.fit(X_train, y_train)
predictions = GBM.predict(X_test)
#the output score comes to be 0.78468

#model8 - KNN, nearest neighbor
from sklearn.neighbors import KNeighborsClassifier
KNN = KNeighborsClassifier()
KNN.fit(X_train, y_train)
predictions = KNN.predict(X_test)
#the output score comes to be 0.6722

#model9 - SGD, stochastic gradient descent
from sklearn.linear_model import SGDClassifier
SGD = SGDClassifier()
SGD.fit(X_train, y_train)
predictions = SGD.predict(X_test)
#the output score comes to be 0.67942

#model10 - Gaussian Naive Bayes
from sklearn.naive_bayes import GaussianNB
GNB = GaussianNB()
GNB.fit(X_train, y_train)
predictions = GNB.predict(X_test)
#the output score comes to be 0.74401

#model11 - SVC, support vector classifier
from sklearn.svm import SVC
SVC = SVC()
SVC.fit(X_train, y_train)
predictions = SVC.predict(X_test)
#the output score comes to be 0.6698

#model12 - Linear SVC
from sklearn.svm import LinearSVC
LinSVC = LinearSVC()
LinSVC.fit(X_train, y_train)
predictions = LinSVC.predict(X_test)
#the output score comes to be 0.770334

#model13 - perceptron ,equivalent to SGDClassifier(loss=”perceptron”, eta0=1, learning_rate=”constant”, penalty=None)
from sklearn.linear_model import Perceptron
per = Perceptron()
per.fit(X_train, y_train)
predictions = per.predict(X_test)
#the output score comes to be 0.75358

#creating confusion matrix and using different threshold for predictions
from sklearn.metrics import confusion_matrix
confusion_matrix(actualpredictions, predictions, labels=[0,1])#if labels = [1,0] the values will be swapped
#create a proper confusion matrix
pd.DataFrame(confusion_matrix(actualpredictions, predictions, labels=[1,0]), columns=[0,1], index=[0,1])
#columns are actual values and rows are predicted values
#e.g. 0,0 (first col first row) means how many are actually 0 and also we predicted 0, 0,1 how may are are actually 0 and how many we predicted 1
#now what logistic regression actually does prediction is based on probabilities, it calculated probabilities and then assigns 1 to values with prob>0.5 and 0 to other values
#also there are other models which predicts probabilitiesm but here we will use logostic regression
#to get probabilities
LogR.predict_proba(X_test)#this will give us two row, first is the probability of 0 and second column is the probability for 1, we only need second column
probs = LogR.predict_proba(X_test)
probs = probs[:,1]
#we can get the default numpy predictions in a couple of ways
defaultLogisticPredictions1 = (probs>0.5).astype('int32')
defaultLogisticPredictions2 = np.where(probs>0.5,1,0)
np.array_equal(defaultLogisticPredictions1,defaultLogisticPredictions2)#both are same
accuracy_score(actualpredictions, defaultLogisticPredictions1)#also the accuracy score we can check and it matched the logistic regression predictions
#we can use different threshold for prediction
predictionUsingDiffThreshold = (probs>0.6).astype('int32')#using threshold of 0.6 instead of default 0.5
accuracy_score(actualpredictions, predictionUsingDiffThreshold)#after calculating i noticed that the accuracy_score actually slightly increased
#first time crossed 80% on kaggle with titanic data set
#** i am using the original test labels for testing my model before posting to kaggle as kaggle has only 10 submission/day, i am not using it for training

#roc curve and roc auc score
from sklearn.metrics import roc_auc_score
roc_auc_score(actualpredictions, probs)#this will give you AUC score for an ROC curve
#ROC curve is a curve between TPR(y axis) and FPR(x axis) for different values of threshold from 0 to 1, a perfect binary classifier will have an roc_auc_score=1
#TPR is also called sensitivity or recall and is given by TP/(TP + FN), FPR=1-specificity(where specificity=TNR=TN/(TN+FP))
#for plotting ROC curve
from sklearn.metrics import roc_curve
tpr, fpr, thresholds = roc_curve(actualpredictions, probs)#roc_curve return three values, tpr, fpr, and thresholds
#you can use these values also to calculate roc auc score
from sklearn.metrics import auc
auc(tpr, fpr)#it is same as roc_auc_score(actualpredictions, probs)
#to plot ROC curve we can do as below
plt.plot(tpr, fpr)
plt.plot([0,1],[0,1])
plt.show()
#also we can do some fancy plotting
plt.plot(tpr, fpr)
plt.plot([0,1],[0,1], c='r')#create diagonal line
plt.plot([0,1],[0,0], c='k')#this and below three lines are to create a square boundry
plt.plot([0,0],[0,1], c='k')
plt.plot([1,0],[1,1], c='k')
plt.plot([1,1],[0,1], c='k')
plt.fill_between(tpr, fpr, color='r', alpha=0.3)#fill area between the curve and the x axis, this is auc
datapoints = list(zip(tpr[::25],fpr[::25],thresholds[::25]))#to get the threshold of few data points
for i in range(len(tpr[::25])):
    plt.text(datapoints[i][0],datapoints[i][1],round(datapoints[i][2],2))#plotting those thresolds to get an idea
plt.show()

#**put roc curve here

#plotting decision trees (you can only plot the decison tree, not any ensemble tree)
from sklearn.tree import DecisionTreeClassifier
Detree = DecisionTreeClassifier()
Detree = Detree.fit(X_train, y_train)
predictions = Detree.predict(X_test)
from sklearn.tree import export_graphviz#this is used to save the tree to a dot file
export_graphviz(Detree, out_file='dtree.png', rounded = True, proportion = False, precision = 2, filled = True)
#now you need to covert dot file to png or jpeg then you can use it to see the tree structure

#important features, feature importance
#for RandomForest and other tree based classifier
importances = RandF.feature_importances_#this will give you the features and their importance
indices = np.argsort(importances)#we sort the indices based on values
importanceSeries = pd.Series(importances[indices], list(X_train.columns[indices]))#create a series of the importance feature
importanceSeries.plot(kind='bar')#we are plotting the above series
plt.show()
#for logistic regression, we can use the coefficient values to check which all features are important
#one thing we can do is by multiplying the coefficient by standard deviations 
pd.Series(abs(np.std(X_train, 0)*LogR.coef_.flatten())).sort_values(ascending=False)
#also instead of doing the above you can fit the model on standarized parameters
#or you can fit the Generalized linear model from statsmodel and use the p values
import statsmodels.api as sm
LogGLM = sm.GLM(y_train,X_train,data=trainData, family=sm.families.Binomial())#family binomial mean logistic or binary model
result = LogGLM.fit()
print(result.summary())#it will print R style summary
#from summary you can check the p values of the variable if the p value < 0.05 the variable is important

#creating an ensemble of classifiers and using simple voting to predict the output
#here i will use 5 of the best performing models from above
from sklearn.ensemble import VotingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from xgboost import XGBClassifier
from sklearn.svm import LinearSVC
from sklearn.naive_bayes import GaussianNB
modl1 = LogisticRegression()
modl2 = RandomForestClassifier()
modl3 = XGBClassifier()
modl4 = LinearSVC()
modl5 = GaussianNB()
vClassifier = VotingClassifier(estimators=[('lor', modl1),('rf', modl2),('xgb', modl3),('svc', modl4),('gnb', modl5)],voting='hard')#hard means do majority voting
vClassifier.fit(X=X_train, y=y_train)
votingPrediction = vClassifier.predict(X=X_test)
accuracy_score(actualpredictions, votingPrediction)#accuracy is better than most individual score but still less conpared to logistic with threshold 0.65071

#cross validation
#we use cross validation to get an estimate of how the model will perform on test data
#usually we divide out train data into k parts and use k-1 parts for training and 1 part for testing and this is done k number of times
#k number of times means each of the k part is treated as test once and remaining data is used for training
#we have libraries in sklearn which will do this automatically and give us the output result
from sklearn.model_selection import cross_val_score
modl1 = LogisticRegression()#our model
scores = cross_val_score(modl1, X_train, y_train, cv=10)#10 fold cross validation
print(scores)
print("Accuracy: %0.2f (+/- %0.2f)" % (scores.mean(), scores.std() * 2))#print average and standard deviation
print("Accuracy: {:.2f} (+/- {:.2f})".format(scores.mean(), scores.std() * 2))#same as above just using .format
#also you can use
from sklearn.model_selection import cross_validate#from this you have to explicitly get the scores
cv_results = cross_validate(modl1, X_train, y_train, cv=10)
cv_results['test_score']#to get the scores, same as scores above

#grid search
#estimators have many hyperparameter which are set to some default values, we can change these values as per our need
#for example in logistic regression we want to give different weight to 1 then 0, so our algorithm will try to correct more 1's compared to 0's
#in random forest we can let tree grow a little bit more depending on some criterian, or in svm we can use different kernels
#we can do all of these things manually but there are so many combination and it will be a headache, so we have Grid Search CV to the rescue
#grid search cv will fit our models for all the combinations of the parameters which we give and also do crossvalidation to test the score
#based on this score it choses which parameter combination is better
#here we will use randomforest classifier to demonstrate this
from sklearn.model_selection import GridSearchCV
parameters = {'n_estimators':[5,7,9,11,13],'criterion':['gini','entropy'],'min_samples_split':[2,4,6,8]}#parameters to do grid search on
RandF = RandomForestClassifier()
GridS = GridSearchCV(RandF, parameters, cv=10)#using 10 fold cross validation with grid search
GridS.fit(X_train, y_train)
GridS.best_estimator_#will give you the best estimator with the best parameter combination
RandFBest = GridS.best_estimator_#you can assign that to a variable
RandFBestPredictions = RandFBest.predict(X_test)#we can use the best_estimator_ to do our predictions
#in my case doing GridSearchCV increased my test accuracy with 1 percent, its just an demonstrating example, you can use this with different algos and different parameters

#creating a correlation matrix and making it easy to read
cols = Data.columns.values#get all the columns on which you want to do the correlation, it can be all the columns or only given columns
#cols = ['col1','col2' etc], you can do like this also
corrMatrix = Data.corr()#it will create a correlation matrix
threshold = 0.5#you can define any threshold, here i want to see all the pairs whose abs correlation value is >=0.5
corr_list = []#create an empty list in which we will store the values
for i in range(10):
    for j in range(i+1, 10):#i+1 as we dont want to repeat the same pair again and again as corr(i,j) is same as corr(j,i)
        if (data_corr.iloc[i, j] >= 0.5 and data_corr.iloc[i, j] < 1) or (data_corr.iloc[i, j] <= -0.5 and data_corr.iloc[i, j] > -1):
            corr_list.append([data_corr.iloc[i, j], i, j])
print(corr_list)#this list is having correlation value and the row index and column index of the variable
sorted_corr_list = sorted(corr_list, key=lambda x: -abs(x[0]))#sorting the correlation matrix based on first value (correlation value) of each row, not on the indices
print(sorted_corr_list)
#now to properly print the correlation values with the columns names instead of indices
for v, i, j in sorted_corr_list:
    print('{} and {} = {:.2f}'.format(cols[i], cols[j], v))#cols is the list of columns we declared earlier

