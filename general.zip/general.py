#some from https://www.youtube.com/watch?v=WiQqqB9MlkA
#magic methods, dunder metthods
#for example you have buld a class and you wanna used + operator on instance of that class you can implement __add__ method
class addd:
    def __init__(self, n):#constructor
        self.n=n
    def __add__(self, other):
        return self.n + other.n
a=addd(1)
b=addd(2)
print(a+b)#this will output 6
#also we can alias method like concat = __add__
class addd:
    def __init__(self, n):
        self.n=n
    def __add__(self, other):
        return self.n + other.n
    concat = __add__
a=addd(1)
b=addd(2)
a.concat(b)#same output as above

#making class iterable
#we have to implement __iter__ and it must return an iterator
#in order to be an iterator a class has to implement __next__ menthod and it must raise StopIteration when no more items are left
#example of above below we create a class which acts similar to range() function
class myRange:
    def __init__(self, n):
        self.n = n
        self.position=0
    def __iter__(self):
        return self
    def __next__(self):
        while self.position<self.n:
            self.position+=1
            return self.position-1
        raise StopIteration
myList = myRange(5)
for i in myList:#we can loop through myList
    print(i)
print(list(myRange(5)))#or we can use it same as we will use range(5)

#creating same code using generator (yield), here we dont't need to use __next__ as generator has already iterator implemented
class myRange:
    def __init__(self, n):
        self.n = n
        self.position=0
    def __iter__(self):
        while self.position<self.n:
            self.position+=1
            yield self.position-1#if you put yield inside __next__ it creates some kind of infinite loop as yield is a generator and has an __iter__ method implemented
myList = myRange(5)
for i in myList:
    print(i)
print(list(myRange(5)))

#getattr
class dog:
    sound='bark'
    def speak(self):
        print(self.sound+'! '+self.sound+'!')
my_dog = dog()
my_dog.speak()#this will print bark! bark!

getattr(my_dog, 'speak')#this will tell you that speak is a bound method and you can assign to something and then you can call it to any method
bark_method = getattr(my_dog, 'speak')#also you can give one more argument for default in case the attribute is not found
bark_method()#this will print bark! bark!

#context manager, as we saw we use with, it basically closes a file or connection once it comes out 
#the context manager used two dunder methods for this
__enter__
__exit__
#a better way to do this is using the contextmanager decorator
from contextlib import contextmanager

#convert binary to int using int function
int('10010', base=2)#returns 18

#functools
#we can use functools to create object which behave like functions with args and kwargs
#we can use the previous example
from functools import partial
basetwo = partial(int, base=2)#here we are creating a function using int function and kwarg base=2
basetwo('10010')#this will return 18

#id
id(object)#returns id of an object, for e.g. if two names are pointing to same number like
a=100
b=100
id(a)==id(b)#returns True id(a) will be equal to id(b)

#copying
a=[1,2,3,4]
b=a#it does not copy the data to b, it just creates one more reference to the data,
#if we do something like b[1]=9, a also changes, to avoid this we can use
b=a[:]#as slicing data copies the data or you can do
b=a.copy() 

#every python variable has three things, a name, a type and a reference

#get size of an object
import sys
gso = sys.getsizeof
lst = [1,2,3,4]
gso(lst)#returns 96, means 96 bytes
gso(0)#returns 24, for single element, so from above 96=24*4
gso(100)#returns 28, depends on the number

#numpy data store location
arr = np.array([1,2,3,4])
arr.data#returns the memory location

#arr.strides
#returns Tuple of bytes to step in each dimension when traversing an array

#strings are immutable
#also keys in dictionaries have to be immutable

#dictionary
#if we know the key exist we can use dict[key] to retrieve data, but when we are not sure we can use .get
dct = {1:'A',2:'B'}
dct[1]#returns A works fine
dct[3]#give keyError, do in this case you can use .get
dct.get(3, 'Key Not Found')#here key not found is a default message in case of keyError

#__getitem__
dic = {'A':1, 'B':2}
print(dic.__getitem__('A'))#will return 1

#__len__
class SomeShape:
    def __len__(self):
        return 4#len method can return int as len can't be a string
ss=SomeShape()
print(len(ss))

#docstring
#we create docstring for a function using triple quotes """ """
def func():
    """
    this is a test function
    """
    pass
help(func)#will give you the docstring 
func.__doc__ #will also give you docstring, also you can use func? in jupyter notebook

#variable in a loop
for i in range(10):
    pass
print(i)#it will print 9, as 9 was the last value assigned to it in the loop

#iterate through a file
#once you have iterated over a file you can't iterate over the same opened file again
testFile = open('..\..\..\\tita\\train.csv')
for i in testOpen:
    print(i,end='\r')#prints the lines
for i in testOpen:#iterating twice
    print(i,end='\r')#prints nothing
testFile.close()

#pretty print
import pprint

#read csv
import csv